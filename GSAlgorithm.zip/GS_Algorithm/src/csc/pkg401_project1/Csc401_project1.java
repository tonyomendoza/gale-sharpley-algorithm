package csc.pkg401_project1;

import java.util.ArrayList;

/**
 *
 * @author Kris Giddens and Tony Mendoza
 */

public class Csc401_project1 {
	static ArrayList<Person> men;
	static ArrayList<Person> women;
	static ArrayList<Person> matchedMen;
	static final int TOTAL_PEOPLE = 20;
	static int unmatchedMen = 0;
	static int proposalCount;

	public static void main(String[] args) {
		System.out.println("=> Application: gale-sharpley-algorithm");
		Initialize();
		TEST_PrintPreferences();
		gsAlgorithm(0);
		printMatches();
		System.out.println(proposalCount);
	}

	// Determine who is admitted in which years
	static void Initialize() {
		int halfSize = TOTAL_PEOPLE / 2;
		System.out.println("=> Initializing the people to match.");
		men = new ArrayList<>(halfSize); // construct structure for the men
		women = new ArrayList<>(halfSize); // construct structure for the women
		matchedMen = new ArrayList<>(); // construct structure for unmatched men

		System.out.println("\t=> Adding the men. " + halfSize);
		for (int m = 0; m < halfSize; m++) { // for every man
			Person man = new Person(m, Person.BinaryGender.M);
			men.add(man);
			// System.out.println("\t\t=> Added: " + man);
		}

		System.out.println("\t=> Adding the women. " + halfSize);
		for (int f = 0; f < halfSize; f++) { // for every woman
			Person woman = new Person(f, Person.BinaryGender.F);
			women.add(woman);
			// System.out.println("\t\t=> Added: " + woman);
		}

		// Create the individualized preference lists for men
		System.out.println("\t=> Creating preference lists for men. " + halfSize);
		for (int m = 0; m < halfSize; m++) { // for every man
			men.get(m).setPreferences(women);
			men.get(m).shufflePreferences();
		}

		// initialize unmatched men list
		// matchedMen;

		// Create the individualized preference lists for women
		System.out.println("\t=> Creating preference lists for women. " + halfSize);
		for (int f = 0; f < halfSize; f++) { // for every woman
			women.get(f).setPreferences(men);
			women.get(f).shufflePreferences();
		}
	}

	public static void TEST_PrintPreferences() {
		System.out.println("\t=> Printing preferences for men. ");
		for (int m = 0; m < men.size(); m++) {
			System.out.println("\t=> " + men.get(m));
			for (int i = 0; i < men.get(m).getPreferences().length; i++)
				System.out.println("\t\t=> " + men.get(m).getPreferences()[i]);
		}

		System.out.println("\t=> Printing preferences for women. ");
		for (int f = 0; f < women.size(); f++) {
			System.out.println("\t=> " + women.get(f));
			for (int i = 0; i < women.get(f).getPreferences().length; i++)
				System.out.println("\t\t=> " + women.get(f).getPreferences()[i]);
		}
	}

	// Create a random number
	static int RandomInt(int length) {
		return (int) (Math.random() * length);
	}

	// determines which man the woman prefers
	static boolean WPrefersMOverM1(Person woman, Person m, Person m1) {
		for (int i = 0; i < TOTAL_PEOPLE / 2; i++) {
			if (woman.getPreference(i) == m.getID()) {
				return true;
			}
			if (woman.getPreference(i) == m1.getID()) {
				return false;
			}
		}
		return false;
	}

	static void gsAlgorithm(int startingMan) {
		int count = startingMan;
		unmatchedMen = men.size();
		//while there is still a free man
		while (unmatchedMen != 0) {
			// if the selected man is free continue
			// else move to next man in list
			if (men.get(count).getPartner() == -1) {
				Person m1 = men.get(count);
				for (int i = 0; i < men.size() && m1.getPartner() == -1;) {
					// if the chosen man has already proposed and been rejected move to 
					// the next choice id preference list
					if (men.get(count).getPreference(i) == -1)
						i++;
					else {
						// if the chosen woman is free get engaged
						if (women.get(m1.getPreference(i)).getPartner() == -1) {
							women.get(m1.getPreference(i)).setPartner(m1.getID());
							men.get(count).setPartner(m1.getPreference(i));
							proposalCount++;
							unmatchedMen--;
						} else {
							// propose and ask woman who she prefers.  if it is the current man switch
							// else move on
							Person womanTemp = women.get(m1.getPreference(i));
							Person womanTemp2 = women.get(m1.getPreference(i));
							Person man1 = men.get(count);
							Person man2 = men.get(womanTemp.getPartner());
							if (WPrefersMOverM1(womanTemp, man1, man2)) {
								men.get(count).setPartner(womanTemp.getID());
								men.get(womanTemp.getPartner()).setPartner(-1);
								women.get(m1.getPreference(i)).setPartner(men.get(count).getID());
								proposalCount++;
								// mark the woman who rejected the man as taken in selected mans preference list
								// so he does not propose to here twice.
								for (int j = 0; j < men.size(); j++) {
									if (men.get(womanTemp2.getPartner()).getPreference(j) == -1)
										continue;
									else {
										men.get(womanTemp2.getPartner()).setPreference(j, -1);
										break;
									}
								}
							} else {
								proposalCount++;
								// mark the woman who rejected the man as taken in selected mans preference list
								// so he does not propose to here twice.
								for (int k = 0; k < men.size(); k++) {
									if (men.get(count).getPreference(k) == -1)
										continue;
									else {
										men.get(count).setPreference(k, -1);
										break;
									}
								}
							}
						}
						break;
					}
				}
			} else if (count == men.size() - 1)
				count = 0;
			else
				count++;
		}
	}

	static void printMatches() {
		for (int i = 0; i < men.size(); i++) {
			System.out.println(men.get(i).getID() + " is matched to " + men.get(i).getPartner());
		}
	}
}